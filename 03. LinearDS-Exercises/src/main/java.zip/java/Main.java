import implementations.ArrayDeque;

public class Main {
    public static void main(String[] args) {

        ArrayDeque<String> asd = new ArrayDeque<>();
        asd.add("a");
        System.out.print(asd.remove(null));
//        integers1.push(14);
//        integers2.push(14);
//
//        integers1.push(13);
//        integers2.push(13);
//
//
//        for (int i = 0; i < 3; i++) {
//
//            System.out.println(i + " pop");
//            System.out.println(integers1.pop());
//            System.out.print(" <-> ");
//            System.out.println(integers2.pop());
//
//        }
//        integers1.push(14);
//        integers2.push(14);
//
//        integers1.push(13);
//        integers2.push(13);
//
//        integers1.push(12);
//        integers2.push(12);

//        integers1.addLast(10);
//        integers2.addLast(10);
//
//        integers1.addLast(13);
//        integers2.addLast(13);
//
//        integers1.addLast(13);
//        integers2.addLast(13);
//
//        integers1.addFirst(9);
//        integers2.addFirst(9);
//
//        integers1.insert(3,12);
//        integers2.insert(3,12);
//
//        integers1.set(2,11);
//        integers2.set(2,11);
//
//        integers1.add(14);
//        integers2.add(14);
//
//        integers1.add(15);
//        integers2.add(15);
//
//        integers1.add(16);
//        integers2.add(16);
//
//        integers1.add(17);
//        integers2.add(17);
//
//        integers1.add(18);
//        integers2.add(18);
//
//        integers1.add(19);
//        integers2.add(19);
//
//        integers1.offer(20);
//        integers2.offer(20);
//
//        integers1.insert(3,20);
//        integers2.insert(3,20);
//
//        integers1.remove((Integer)20);
//        integers1.remove((Integer)20);
//
//        System.out.println("poll");
//        System.out.print(integers1.poll());
//        System.out.print(" <-> ");
//        System.out.println(integers2.poll());
//
//        System.out.println("pop");
//        System.out.print(integers1.pop());
//        System.out.print(" <-> ");
//        System.out.println(integers2.pop());
//
//        System.out.println("peek");
//        System.out.print(integers1.peek());
//        System.out.print(" <-> ");
//        System.out.println(integers2.peek());
//
//        System.out.println("peek");
//        System.out.print(integers1.peek());
//        System.out.print(" <-> ");
//        System.out.println(integers2.peek());
//
//        System.out.println("get");
//        System.out.print(integers1.get(2));
//        System.out.print(" <-> ");
//        System.out.println(integers2.get(2));
//
//
//        System.out.println("foreach");
//        for (Integer integer : integers1)
//            System.out.print(integer + " ");
//        System.out.println();
//        for (Integer integer : integers2)
//            System.out.print(integer + " ");
//        System.out.println();
    }
}