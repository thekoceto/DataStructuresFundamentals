package model;

public interface Task {
    int getId();
    void setId(int id);
    String getDescription();
    void setDescription(String description);
}
