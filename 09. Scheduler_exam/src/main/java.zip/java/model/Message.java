package model;

public interface Message {
    int getWeight();
    void setWeight(int weight);
    String getText();
    void setText(String text);
}
