import core.MessagingSystem;
import core.ProcessScheduler;
import model.Message;
import model.ScheduledTask;
import model.TextMessage;
import shared.DataTransferSystem;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Message> messages = List.of(
                    new TextMessage(11, "test_text"),
                    new TextMessage(6, "test_text"),
                    new TextMessage(19, "test_text"),
                    new TextMessage(4, "test_text"),
                    new TextMessage(8, "test_text"),
                    new TextMessage(17, "test_text")
        );
        DataTransferSystem system =  new MessagingSystem();
        for (Message message : messages) {
            system.add(message);
        }

        List<Message> orderedByWeight = system.getOrderedByWeight();


        orderedByWeight.forEach(message -> System.out.print(message.getWeight() + " "));


//        ProcessScheduler processScheduler = new ProcessScheduler();
//        processScheduler.add(new ScheduledTask(1, "test_description "));
//        processScheduler.add(new ScheduledTask(2, "test_description "));

//        for (int i = 1; i <= 20; i++)
//            processScheduler.add(new ScheduledTask(i, "test_description "));

//        processScheduler.insertBefore(1, new ScheduledTask(0, "test_description "));
//        processScheduler.insertAfter(2, new ScheduledTask(3, "test_description "));

//        System.out.println(processScheduler.contains(new ScheduledTask(21, "test_description ")));
//        processScheduler.process();


    }

}