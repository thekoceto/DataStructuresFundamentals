package core;

import interfaces.Entity;
import interfaces.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class Data implements Repository {
    private List <Entity> entities;

    public Data() {
        this.entities = new LinkedList<>();
    }
    public Data(List<Entity> entities) {
        this.entities = new LinkedList<>(entities);
    }

    @Override
    public void add(Entity entity) {
        this.entities.add(entity);
        Collections.sort(this.entities);
    }
    @Override
    public Entity getById(int id) {
        return this.entities.get(id);
    }

    @Override
    public List<Entity> getByParentId(int id) {
        return this.entities
                .stream()
                .filter(entity -> entity.getParentId() == id)
                .collect(Collectors.toList());
    }

    @Override
    public List<Entity> getAll() {
        return new LinkedList(this.entities);
    }

    @Override
    public Repository copy() {
        return new Data(this.entities);
    }

    @Override
    public List<Entity> getAllByType(String type) {
        if (!type.equals("User") && !type.equals("StoreClient") && !type.equals("Invoice"))
            throw new IllegalArgumentException ("Illegal type: " + type);

        return this.entities
                .stream()
                .filter(entity -> entity.getClass().getSimpleName().equals(type))
                .collect(Collectors.toList());
    }

    @Override
    public Entity peekMostRecent() {
        if (this.entities.isEmpty())
            throw new IllegalStateException("Operation on empty Data");

        return this.entities.get(this.entities.size()-1);
    }

    @Override
    public Entity pollMostRecent() {
        if (this.entities.isEmpty())
            throw new IllegalStateException("Operation on empty Data");

        return this.entities.remove(this.entities.size()-1);
    }

    @Override
    public int size() {
        return this.entities.size();
    }
}
