import core.FileExplorer;
import model.SampleFile;
import shared.FileManager;

public class Main {
    public static void main(String[] args) {
//        FileManager fileManager = new FileExplorer();
//        fileManager.addInDirectory(1, new SampleFile(45, "test_name"));
//        fileManager.addInDirectory(1, new SampleFile(84, "test_name"));
//        fileManager.addInDirectory(1, new SampleFile(38, "test_name"));
//        fileManager.addInDirectory(45, new SampleFile(10, "test_name"));
//        fileManager.addInDirectory(45, new SampleFile(62, "test_name"));
//        fileManager.addInDirectory(84, new SampleFile(59, "test_name"));
//        fileManager.addInDirectory(59, new SampleFile(24, "test_name"));
//        fileManager.addInDirectory(10, new SampleFile(49, "test_name"));
//        fileManager.addInDirectory(49, new SampleFile(44, "test_name"));
//        fileManager.addInDirectory(62, new SampleFile(80, "test_name"));
//        fileManager.addInDirectory(62, new SampleFile(6, "test_name"));
//        fileManager.addInDirectory(62, new SampleFile(91, "test_name"));
//        fileManager.addInDirectory(80, new SampleFile(5, "test_name"));
//        fileManager.addInDirectory(5, new SampleFile(6, "test_name"));
//        fileManager.addInDirectory(80, new SampleFile(0, "test_name"));
//        fileManager.addInDirectory(91, new SampleFile(65, "test_name"));
//        fileManager.addInDirectory(6, new SampleFile(21, "test_name"));
//
//        System.out.println(fileManager.getAsString());
//        System.out.println("---------------------");
//
//        fileManager.deleteFile(new SampleFile(91, "test_name"));
//
//        System.out.println(fileManager.getAsString());
    }
}